requirejs( [ 'require', 'jquery', 'https://unpkg.com/masonry-layout@4.2.0/dist/masonry.pkgd.min.js' ],
function( require, $, Masonry ) {
    require( [ 'jquery-bridget/jquery-bridget' ],
    function( jQueryBridget ) {
        jQueryBridget( 'masonry', Masonry, $ );
        $('.category-cms .masnGrid').masonry({
            itemSelector: '.grid-item',
			columnWidth: '.col',
			gutter: 0,
			percentPosition: true
        });
    });
});